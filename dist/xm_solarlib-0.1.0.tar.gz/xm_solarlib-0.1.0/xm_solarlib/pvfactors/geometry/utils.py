import numpy as np
from pvfactors.config import TOL_COLLINEAR, DISTANCE_TOLERANCE
from shapely.geometry import LineString, MultiLineString


def difference(u, v):
    """Calculate difference between two lines, avoiding shapely float
    precision errors

    Parameters
    ----------
    u : :py:class:`shapely.geometry.LineString`-like
        Line string from which ``v`` will be removed
    v : :py:class:`shapely.geometry.LineString`-like
        Line string to remove from ``u``

    Returns
    -------
    :py:class:`shapely.geometry.LineString`
       Resulting difference of current surface minus given linestring
    """
    ub1, ub2 = u.boundary
    vb1, vb2 = v.boundary
    u_contains_vb1 = contains(u, vb1)
    u_contains_vb2 = contains(u, vb2)
    v_contains_ub1 = contains(v, ub1)
    v_contains_ub2 = contains(v, ub2)

    if u_contains_vb1:
        if u_contains_vb2:
            l_tmp = LineString([ub1, vb1])
            if contains(l_tmp, vb2):
                list_lines = [LineString([ub1, vb2]), LineString([vb1, ub2])]
            else:
                list_lines = [LineString([ub1, vb1]), LineString([vb2, ub2])]
            # Note that boundary points can be equal, so need to make sure
            # we're not passing line strings with length 0
            final_list_lines = [line for line in list_lines
                                if line.length > DISTANCE_TOLERANCE]
            len_final_list = len(final_list_lines)
            if len_final_list == 2:
                return MultiLineString(final_list_lines)
            elif len_final_list == 1:
                return final_list_lines[0]
            else:
                return LineString()
        elif v_contains_ub1:
            if v_contains_ub2:
                return LineString()
            else:
                return LineString([vb1, ub2])
        elif v_contains_ub2:
            return LineString([ub1, vb1])
        else:
            return u
    elif u_contains_vb2:
        if v_contains_ub1:
            if v_contains_ub2:
                return LineString()
            else:
                return LineString([vb2, ub2])
        elif v_contains_ub2:
            return LineString([ub1, vb2])
        else:
            return u
    else:
        return u
       

def contains(linestring, point, tol_distance=DISTANCE_TOLERANCE):
    """Fixing floating point errors obtained in shapely for contains"""
    return linestring.distance(point) < tol_distance


def is_collinear(list_elements):
    """Check that all :py:class:`~pvfactors.pvsurface.PVSegment`
    or :py:class:`~pvfactors.pvsurface.PVSurface` objects in list
    are collinear"""
    is_col = True
    u_direction = None  # will be orthogonal to normal vector
    for element in list_elements:
        if not element.is_empty:
            if u_direction is None:
                # set u_direction if not defined already
                u_direction = np.array([- element.n_vector[1],
                                        element.n_vector[0]])
            else:
                # check that collinear
                dot_prod = u_direction.dot(element.n_vector)
                is_col = np.abs(dot_prod) < TOL_COLLINEAR
                if not is_col:
                    return is_col
    return is_col


def check_collinear(list_elements):
    """Raise error if all :py:class:`~pvfactors.pvsurface.PVSegment`
    or :py:class:`~pvfactors.pvsurface.PVSurface` objects in list
    are not collinear"""
    is_col = is_collinear(list_elements)
    if not is_col:
        msg = "All elements should be collinear"
        raise Exception(msg)
    

def are_2d_vecs_collinear(u1, u2):
    """Check that two 2D vectors are collinear"""
    n1 = np.array([-u1[1], u1[0]])
    dot_prod = n1.dot(u2)
    return np.abs(dot_prod) < TOL_COLLINEAR