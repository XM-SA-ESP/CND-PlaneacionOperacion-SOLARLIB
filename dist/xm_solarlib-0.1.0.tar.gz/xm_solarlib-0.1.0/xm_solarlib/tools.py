import numpy as np
import pandas as pd
import warnings

def cosd(angle):
    """
    Cosine with angle input in degrees

    Parameters
    ----------
    angle : float or array-like
        Angle in degrees

    Returns
    -------
    result : float or array-like
        Cosine of the angle
    """

    res = np.cos(np.radians(angle))
    return res


def sind(angle):
    """
    Sine with angle input in degrees

    Parameters
    ----------
    angle : float
        Angle in degrees

    Returns
    -------
    result : float
        Sin of the angle
    """

    res = np.sin(np.radians(angle))
    return res


def asind(number):
    """
    Inverse Sine returning an angle in degrees

    Parameters
    ----------
    number : float
        Input number

    Returns
    -------
    result : float
        arcsin result
    """

    res = np.degrees(np.arcsin(number))
    return res


def acosd(number):
    """
    Inverse Cosine returning an angle in degrees

    Parameters
    ----------
    number : float
        Input number

    Returns
    -------
    result : float
        arccos result
    """

    res = np.degrees(np.arccos(number))
    return res


def _golden_sect_DataFrame(params, lower, upper, func, atol=1e-8):
    """
    Vectorized golden section search for finding maximum of a function of a
    single variable.

    Parameters
    ----------
    params : dict of numeric
        Parameters to be passed to `func`. Each entry must be of the same
        length.

    lower: numeric
        Lower bound for the optimization. Must be the same length as each
        entry of params.

    upper: numeric
        Upper bound for the optimization. Must be the same length as each
        entry of params.

    func: function
        Function to be optimized. Must be in the form
        result = f(dict or DataFrame, str), where result is a dict or DataFrame
        that also contains the function output, and str is the key
        corresponding to the function's input variable.

    Returns
    -------
    numeric
        function evaluated at the optimal points

    numeric
        optimal points

    Notes
    -----
    This function will find the points where the function is maximized.
    Returns nan where lower or upper is nan, or where func evaluates to nan.

    See also
    --------
    xm_solarlib.singlediode._pwr_optfcn
    """
    if np.any(upper - lower < 0.):
        raise ValueError('upper >= lower is required')

    phim1 = (np.sqrt(5) - 1) / 2

    df = params.copy()  # shallow copy to avoid modifying caller's dict
    df['VH'] = upper
    df['VL'] = lower

    converged = False

    while not converged:

        phi = phim1 * (df['VH'] - df['VL'])
        df['V1'] = df['VL'] + phi
        df['V2'] = df['VH'] - phi

        df['f1'] = func(df, 'V1')
        df['f2'] = func(df, 'V2')
        df['SW_Flag'] = df['f1'] > df['f2']

        df['VL'] = df['V2']*df['SW_Flag'] + df['VL']*(~df['SW_Flag'])
        df['VH'] = df['V1']*~df['SW_Flag'] + df['VH']*(df['SW_Flag'])

        err = abs(df['V2'] - df['V1'])

        # handle all NaN case gracefully
        with warnings.catch_warnings():
            warnings.filterwarnings(action='ignore',
                                    message='All-NaN slice encountered')
            converged = np.all(err[~np.isnan(err)] < atol)

    # best estimate of location of maximum
    df['max'] = 0.5 * (df['V1'] + df['V2'])
    func_result = func(df, 'max')
    x = np.where(np.isnan(func_result), np.nan, df['max'])
    if np.isscalar(df['max']):
        # np.where always returns an ndarray, converting scalars to 0d-arrays
        x = x.item()

    return func_result, x
def _build_args(keys, input_dict, dict_name):
    """
    Parameters
    ----------
    keys : iterable
        Typically a list of strings.
    input_dict : dict-like
        A dictionary from which to pull each key.
    dict_name : str
        A variable name to include in an error message for missing keys

    Returns
    -------
    kwargs : list
        A list with values corresponding to keys
    """
    try:
        args = [input_dict[key] for key in keys]
    except KeyError as e:
        missing_key = e.args[0]
        msg = (f"Missing required parameter '{missing_key}'. Found "
               f"{input_dict} in {dict_name}.")
        raise KeyError(msg)
    return args



def _build_kwargs(keys, input_dict):
    """
    Parameters
    ----------
    keys : iterable
        Typically a list of strings.
    input_dict : dict-like
        A dictionary from which to attempt to pull each key.

    Returns
    -------
    kwargs : dict
        A dictionary with only the keys that were in input_dict
    """

    kwargs = {}
    for key in keys:
        try:
            kwargs[key] = input_dict[key]
        except KeyError:
            pass

    return kwargs

def get_pandas_index(*args):
    """
    Get the index of the first pandas DataFrame or Series in a list of
    arguments.

    Parameters
    ----------
    args: positional arguments
        The numeric values to scan for a pandas index.

    Returns
    -------
    A pandas index or None
        None is returned if there are no pandas DataFrames or Series in the
        args list.
    """
    return next(
        (a.index for a in args if isinstance(a, (pd.DataFrame, pd.Series))),
        None
    )


def _degrees_to_index(degrees, coordinate):
    """Transform input degrees to an output index integer.
    Specify a degree value and either 'latitude' or 'longitude' to get
    the appropriate index number for these two index numbers.
    Parameters
    ----------
    degrees : float or int
        Degrees of either latitude or longitude.
    coordinate : string
        Specify whether degrees arg is latitude or longitude. Must be set to
        either 'latitude' or 'longitude' or an error will be raised.
    Returns
    -------
    index : np.int16
        The latitude or longitude index number to use when looking up values
        in the Linke turbidity lookup table.
    """
    # Assign inputmin, inputmax, and outputmax based on degree type.
    if coordinate == 'latitude':
        inputmin = 90
        inputmax = -90
        outputmax = 2160
    elif coordinate == 'longitude':
        inputmin = -180
        inputmax = 180
        outputmax = 4320
    else:
        raise IndexError("coordinate must be 'latitude' or 'longitude'.")

    inputrange = inputmax - inputmin
    scale = outputmax/inputrange  # number of indices per degree
    center = inputmin + 1 / scale / 2  # shift to center of index
    outputmax -= 1  # shift index to zero indexing
    index = (degrees - center) * scale
    err = IndexError('Input, %g, is out of range (%g, %g).' %
                     (degrees, inputmin, inputmax))

    # If the index is still out of bounds after rounding, raise an error.
    # 0.500001 is used in comparisons instead of 0.5 to allow for a small
    # margin of error which can occur when dealing with floating point numbers.
    if index > outputmax:
        if index - outputmax <= 0.500001:
            index = outputmax
        else:
            raise err
    elif index < 0:
        if -index <= 0.500001:
            index = 0
        else:
            raise err
    # If the index wasn't set to outputmax or 0, round it and cast it as an
    # integer so it can be used in integer-based indexing.
    else:
        index = int(np.around(index))

    return index


def _pandas_to_doy(pd_object):
    """
    Finds the day of year for a pandas datetime-like object.

    Useful for delayed evaluation of the dayofyear attribute.

    Parameters
    ----------
    pd_object : DatetimeIndex or Timestamp

    Returns
    -------
    dayofyear
    """
    return pd_object.dayofyear
