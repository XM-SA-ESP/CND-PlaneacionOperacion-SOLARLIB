TZ_AMERICA__PHOENIX = 'America/Phoenix'

TZ_US_ARIZONA = 'US/Arizona'

LENGTH_MISMATCH = "Length mismatch for per-array parameter"

SOL_HORIZONTE = '-0:34'